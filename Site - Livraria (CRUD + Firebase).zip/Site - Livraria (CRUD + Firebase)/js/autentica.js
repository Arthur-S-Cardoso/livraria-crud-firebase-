firebase.auth().languageCode='pt_BR'

FrmAutentica.onsubmit = function (event)
{
   event.preventDefault() //evita o envio do formulário

   //caso estiver acessando com e-mail e senha válidos
   console.log(FrmAutentica.FrmAutenticaSubmit.innerHTML)
   if(FrmAutentica.FrmAutenticaSubmit.innerHTML == "Acessar")
   {
      firebase.auth().signInWithEmailAndPassword(FrmAutentica.email.value, FrmAutentica.senha.value).then(function(user)
      {
         alert('Acesso realizado com sucesso');
      }).catch(function (error)
      {
         alert('Erro! Acesso negado')
      })
   }
   else
   {
      //caso queira incluir um novo usuário
      firebase.auth().createUserWithEmailAndPassword(FrmAutentica.email.value, FrmAutentica.senha.value).then(function(user)
      {
         alert('Usuário cadastrado com sucesso');
      }).catch(function(error)
      {
         alert('Falha ao cadastrar o usuário')
      })
   }

}

//FUNÇÃO QUE CENTRALIZA E TRATA A AUTENTICAÇÃO
firebase.auth().onAuthStateChanged(function (user)
{
   if(user)
   {
      MostraItem(Log)
      UsuarioLogadoTitulo.innerHTML = 'Usuário Logado: ' + user.email
      imgUsuario.src = user.photoURL ? user.photoURL : 'img/semfoto.png'
      //console.log(user)
      if (user.emailVerified) {
         OcultaItem(EnviaVerificaEmail)
         VerificaEmail.innerHTML = 'E-mail Verificado'
      } else {
         MostraItem(EnviaVerificaEmail)
         VerificaEmail.innerHTML = 'E-mail não Verificado'
      }
      OcultaItem(auth)
      //mostraVeiculos()
   }
   else
   {
      OcultaItem(Log)
      MostraItem(auth)
   }
})

function sair()
{
   firebase.auth().signOut().then(function()
   {
      alert('Usuário desconectado com sucesso')
   }).catch(function(error)
   {
      alert('Falha ao sair da conta')
   })
   FrmAutentica.email.value = ''
   FrmAutentica.senha.value = ''
}

function excluirUsuario()
{
   var confirma = confirm('Confirma a exclusão deste usuário?')
   if(confirma)
   {
      firebase.auth().currentUser.delete().then(function()
      {
         alert('Conta excluída com sucesso');
      }).catch(function(error)
      {
         alert('Erro ao excluir a conta do usuário')
      })
   }
   FrmAutentica.email.value = ''
   FrmAutentica.senha.value = ''
}


//Função que verifica o e-mail cadastrado
function verificaEmail() {
   user = firebase.auth().currentUser
   user.sendEmailVerification(atualizarUrl).then(function () {
      alert('E-mail de verificação foi enviado para ' + user.email + ' Verifique a sua caixa de entrada.')
   }).catch(function (error) {
      alert('Erro ao enviar e-mail de verificação')
   })
}

function LoginGoogle(){
   //MostraItem(Carregando)
   firebase.auth().signInWithPopup(new firebase.auth.GoogleAuthProvider()).catch(function(erro){
      alert('Erro de autenticação com o servidor da Google')
      console.log(error);
      //OcultaItem(Carregando);
   })
}