var Registrar = document.getElementById('Registrar');
var Acessar = document.getElementById('Acessar');
var FrmAutentica = document.getElementById('FrmAutentica');
var FrmAutenticaTitulo = document.getElementById('FrmAutenticaTitulo');
var FrmAutenticaSubmit = document.getElementById('FrmAutenticaSubmit');
var FrmCidade = document.getElementById('FrmCidade');//REVISAR ESSA LINHA
var VerificaEmail = document.getElementById('VerificaEmail');
var EnviaVerificaEmail = document.getElementById('EnviaVerificaEmail');
var filtro = document.getElementById('filtro');
var FrmLivro = document.getElementById('FrmLivro')
var FrmVenda = document.getElementById('FrmVenda');
//var btnCidades = document.getElementById('btnCidades')

var atualizarUrl = {
   url: 'http://127.0.0.1:5500/'
}

function OcultaItem(element){
   element.style.display = 'none';
}

function MostraItem(element){
   element.style.display = 'block';
}

//altera a visualização do elemento para cadastrar 
function RealizarCadastro(){
   FrmAutenticaTitulo.innerHTML = 'Crie a sua conta';
   FrmAutentica.FrmAutenticaSubmit.innerHTML = 'Cadastrar-se';
   OcultaItem(Registrar);
   MostraItem(Acessar);
}

function RealizarAcesso(){
   FrmAutenticaTitulo.innerHTML = 'Acesse sua conta';
   FrmAutentica.FrmAutenticaSubmit.innerHTML = 'Acessar';
   OcultaItem(Acessar);
   MostraItem(Registrar);
}

function acessou(){
   OcultaItem(FrmVendas);
   OcultaItem(ListaVendas);
   OcultaItem(FrmLivro);
   OcultaItem(ListaLivros);
   MostraItem(btnLivros);
   MostraItem(btnVendas);
}


function mostraLivros(){
   OcultaItem(FrmVendas);
   OcultaItem(ListaVendas);
   MostraItem(FrmLivro);
   MostraItem(ListaLivros);
   OcultaItem(btnLivros);
   MostraItem(btnVendas);
   listaLivros();
}

function mostrarVendas(){
   OcultaItem(FrmLivro);
   OcultaItem(ListaLivros);
   MostraItem(FrmVendas);
   MostraItem(ListaVendas);
   OcultaItem(btnVendas);
   MostraItem(btnLivros);
   listaVendas();
   MenuLivros();
}

OcultaItem(FrmVendas);
OcultaItem(ListaVendas);
OcultaItem(FrmLivro);
OcultaItem(ListaLivros);