  /*
  // Import the functions you need from the SDKs you need
  import { initializeApp } from "https://www.gstatic.com/firebasejs/9.14.0/firebase-app.js";
  // TODO: Add SDKs for Firebase products that you want to use
  // https://firebase.google.com/docs/web/setup#available-libraries

  // Your web app's Firebase configuration
  */

  var firebaseConfig = {
    apiKey: "AIzaSyCGPlj3cVXooO8S7rfCJTOLFl5KO3ZBjNQ",
    authDomain: "bd-prog-cardoso.firebaseapp.com",
    projectId: "bd-prog-cardoso",
    storageBucket: "bd-prog-cardoso.appspot.com",
    messagingSenderId: "56994151825",
    appId: "1:56994151825:web:0ddf045224de2a2d8bee30"
  };

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);