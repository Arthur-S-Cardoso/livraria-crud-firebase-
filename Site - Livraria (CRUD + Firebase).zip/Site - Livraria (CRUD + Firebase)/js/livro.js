FrmLivro.onsubmit = function (event) {
   event.preventDefault() // Evita o redirecionamento da página
   if (TituloFormLivro.innerHTML == "Cadastrar um novo livro") {
      if (FrmLivro.liv_titulo.value == '') {
         alert('O título não pode ser em branco!')
         FrmLivro.liv_titulo.focus();
      } else if (FrmLivro.liv_ano.value == '') {
         alert('O campo ano não pode ser em branco!')
         FrmLivro.liv_ano.focus();
      } else if (FrmLivro.liv_preco.value == '') {
         alert('O campo preço não pode ser em branco!')
         FrmLivro.liv_preco.focus();
      } else if (FrmLivro.liv_autor.value == '') {
         alert('O campo autor não pode ser em branco!')
         FrmLivro.veic_autor.focus();
      }
      else {
         var livro = new Livro(0, 
            FrmLivro.liv_titulo.value,
            FrmLivro.liv_titulo.value.toLowerCase(),
            FrmLivro.liv_ano.value,
            FrmLivro.liv_preco.value,
            FrmLivro.liv_autor.value);

         livro.incluir();    
         limparCampos();
       
      }
   } else {
      var confirmation = confirm('Confirma a alteração dos dados?')
      if (confirmation) {
         var livro = new Livro(0, 
            FrmLivro.liv_titulo.value,
            FrmLivro.liv_titulo.value.toLowerCase(),
            FrmLivro.liv_ano.value,
            FrmLivro.liv_preco.value,
            FrmLivro.liv_autor.value);

         livro.alterar();    
      }
      cancelaUpdate()
   }
}


//Listagem dos livros
function listaLivros() {
   firebase.firestore().collection('LIVROS')
      .orderBy('Titulo').onSnapshot(function (dataSnapshot) {
         geralistaLivros(dataSnapshot)
      })
   filtro.onkeyup = function () {
      if (filtro.value != '') {
         var TextoFiltro = filtro.value.toLowerCase()
         firebase.firestore().collection('LIVROS').orderBy('TituloMinusculo').startAt(TextoFiltro).endAt(TextoFiltro + '\uf8ff').get().then(function (dataSnapshot) {
               //console.log(dataSnapshot)
               geralistaLivros(dataSnapshot)
            })
      } else {
         firebase.firestore().collection('LIVROS')
            .orderBy('Titulo').onSnapshot(function (dataSnapshot) {
               geralistaLivros(dataSnapshot)
            })
      }
   }
}


//Monta a exibição da listagem de livros
function geralistaLivros(dataSnapshot) {
   ulListaLivros.innerHTML = ''
   var num = dataSnapshot.size

   // Exibe o número de cidades
   ContaLivros.innerHTML = 'Total de registros: ' + num + (num > 1 ? ' Livros' : ' livros') + '.'
   dataSnapshot.forEach(function (item) { // Percorre todos os elementos
      var value = item.data()

      var li = document.createElement('li') // Cria um elemento do tipo li

      li.id = item.id // Define o id do li como a chave da veiculo

      var spanLi = document.createElement('span') // Cria um elemento do tipo span
      spanLi.appendChild(document.createTextNode(value.Titulo + ' / ' + value.Autor)) // Adiciona o elemento de texto dentro da nossa span
      li.appendChild(spanLi) // Adiciona o span dentro do li

      //ADICIONA O BOTÃO PARA ALTERAR
      var liUpdateBtn = document.createElement('button') // Cria um botão para a remoção da tarefa
      liUpdateBtn.appendChild(document.createTextNode('Alterar')) // Define o texto do botão como 'Excluir'

      liUpdateBtn.setAttribute('onclick', 'alteraLivros(\"' + item.id + '\")')
      // Configura o onclick do botão de atualização

      liUpdateBtn.setAttribute('class', 'CorBotaoDeletarAlterar') // Define classes de estilização para o nosso botão de remoção
      li.appendChild(liUpdateBtn) // Adiciona o botão de remoção no li

      //ADICIONA O BOTÃO PARA EXCLUIR
      var liRemoveBtn = document.createElement('button') // Cria um botão para a remoção da tarefa
      liRemoveBtn.appendChild(document.createTextNode('Excluir')) // Define o texto do botão como 'Excluir'

      liRemoveBtn.setAttribute('class', 'CorBotaoDeletarExcluir') // Define classes de estilização para o nosso botão de remoção

      liRemoveBtn.setAttribute('type', 'button')

      liRemoveBtn.setAttribute('onclick', 'excluiLivro(\"' + item.id + '\")') // Configura o onclick do botão de remoção de tarefas

      li.appendChild(liRemoveBtn) // Adiciona o botão de remoção no li


      ulListaLivros.appendChild(li) // Adiciona o li dentro da lista de tarefas
   })
}

//FUNÇÃO PARA EXCLUIR UMA CIDADE
var NomeLivro = null
function excluiLivro(key) {
   console.log('Chegou no excluir');
   console.log(key);
   firebase.firestore().collection('LIVROS').doc(key).get().then(function (dados) {
      if (dados.exists) {
         var liv = dados.data()
         var livro = new Livro(key, liv.Titulo, liv.Ano,
            liv.Preco, liv.Titulo);
            NomeLivro = liv.Titulo
         var confimation = confirm('Realmente deseja remover o livro \"' + NomeLivro + '\"?')
         if (confimation) {
            livro.excluir();
         }
      }
   })
}



//FUNÇÃO QUE BUSCA OS DADOS QUE SERÃO ALTERADOS E PREPARA O FORMULÁRIO.
var updateKey = null //cria uma variável global e inicializa com null
function alteraLivros(key) {
   console.log('Entrou no altera');
   updateKey = key // Atribui o conteúdo de key dentro de uma variável global
   firebase.firestore().collection('LIVROS').doc(key).get().then(function (dados) {
      if (dados.exists) {
         //Preenche o formulário com os dados da cidade selecionada
         var liv = dados.data()
         FrmLivro.liv_titulo.value = liv.Titulo
         FrmLivro.liv_ano.value = liv.Ano
         FrmLivro.liv_preco.value = liv.Preco
         FrmLivro.liv_autor.value = liv.Autor
         

         // Altera o título do formulário
         TituloFormLivro.innerHTML = 'Editar o Livro: ' + liv.Titulo;
         OcultaItem(FrmLivroBtnGravar)
         MostraItem(FrmLivroBtnAlterar)

      }
   })

}

function limparCampos(){
   console.log("entrou no limpar");
   FrmLivro.liv_titulo.value = ''
   FrmLivro.liv_ano.value = ''
   FrmLivro.liv_preco.value = ''
   FrmLivro.liv_autor.value = ''

}


//FUNÇÃO PARA RESTAURAR O FORMULÁRIO DE LIVRO QUANDO O USUÁRIO 
//CANCELA UMA ALTERAÇÃO
function cancelaUpdate() {
   TituloFormLivro.innerHTML = 'Cadastrar um novo livro'
   OcultaItem(FrmLivroBtnAlterar)
   MostraItem(FrmLivroBtnGravar)
   FrmLivroBtnGravar.style.display = 'initial'
   limparCampos();
}