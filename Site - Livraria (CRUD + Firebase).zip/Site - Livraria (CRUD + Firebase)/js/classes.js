/*
Veiculo = Livro
id = id
modelo = titulo
modeloMinusculo = tituloMinusculo
ano = ano
marca = preco
cor = autor
*/

class Livro{
    constructor(id, titulo, tituloMinusculo, ano, preco, autor){
        this.id = id;
        this.titulo = titulo;
        this.tituloMinusculo = tituloMinusculo;
        this.ano = ano;
        this.preco = preco;
        this.autor = autor;
    }
    toString(){
        return{
            Titulo : this.titulo,
            TituloMinusculo : this.tituloMinusculo,
            Ano : this.ano,
            Preco : this.preco,
            Autor : this.autor
        };
    }
    incluir(){
        firebase.firestore().collection('LIVROS').add(this.toString())
            .then((docRef) => {
               console.log("Livro cadastrado com ID: ", docRef.id);
               alert('Livro cadastrado com sucesso.')

            })
            .catch((error) => {
               console.error("Erro ao adicionar um documento: ", error);
               alert('Erro ao cadastrar um Livro');
            });
    }
    
    alterar(){
        firebase.firestore().collection('LIVROS').doc(updateKey).update(this.toString()).then(function () {
            alert('Registro alterado com sucesso.')
         }).catch(function (error) {
            console.log('Falha ao alterar os dados: ', error)
         })
    }

    excluir(){
        //ModeloVeiculo = TituloLivro        modelo = titulo
        var TituloLivro = this.titulo;
        firebase.firestore().collection('LIVROS').doc(this.id).delete().then(function () {
            alert('Livro "' + TituloLivro + '" removido com sucesso.')
         }).catch(function (error) {
            console.log('Falha ao remover o livro: ', error)
         })
    }
}

//classe Venda

class Venda{
    constructor(id, comprador, compradorMinusculo, valor, veiculo){
        this.id = id;
        this.comprador = comprador;
        this.compradorMinusculo = compradorMinusculo;
        this.valor = valor;
        this.veiculo = veiculo;
    }

    toString(){
        return{
            Comprador : this.comprador,
            CompradorMinusculo : this.compradorMinusculo,
            Valor : this.valor,
            Veiculo : this.veiculo
        };
    }
    incluir(){
        firebase.firestore().collection('VENDAS').add(this.toString())
            .then((docRef) => {
               console.log("Venda cadastrada com ID: ", docRef.id);
               alert('Venda cadastrada com sucesso.')

            })
            .catch((error) => {
               console.error("Erro ao adicionar um documento: ", error);
               alert('Erro ao cadastrar uma venda');
            });
    }
    
    alterar(){
        firebase.firestore().collection('VENDAS').doc(updateKeyVenda).update(this.toString()).then(function () {
            alert('Registro alterado com sucesso.')
         }).catch(function (error) {
            console.log('Falha ao alterar os dados: ', error)
         })
    }

    excluir(){
        var CompradorVenda = this.comprador;
        firebase.firestore().collection('VENDAS').doc(this.id).delete().then(function () {
            alert('Venda do comprador "' + CompradorVenda + '" foi removida com sucesso.')
         }).catch(function (error) {
            console.log('Falha ao remover a venda: ', error)
         })
    }
}