FrmVendas.onsubmit = function (event) {
    event.preventDefault() // Evita o redirecionamento da página
    if (TituloFormVendas.innerHTML == "Cadastrar uma nova venda") {
      if (FrmVendas.vend_comprador.value == '') {
         alert('O nome do comprador não pode ser em branco!')
         FrmVendas.vend_comprador.focus();
      } else if (FrmVendas.vend_valor.value == '') {
         alert('O campo valor da venda não pode ser em branco!')
         FrmVendas.vend_valor.focus();
      } else if(FrmVendas.vend_livro.value == '') {
         alert('O campo livro da venda não pode ser em branco!')
         FrmVendas.vend_livro.focus();
      } else {
         var venda = new Venda(0, FrmVendas.vend_comprador.value,
            FrmVendas.vend_comprador.value.toLowerCase(),
            FrmVendas.vend_valor.value,
            FrmVendas.vend_livro.value
            );
 
         venda.incluir();    
         limparCamposVenda();
      }
      } else {
         var confirmation = confirm('Confirma a alteração dos dados?')
         if (confirmation) {
            var venda = new Venda(0, 
               FrmVendas.vend_comprador.value,
               FrmVendas.vend_comprador.value.toLowerCase(),
               FrmVendas.vend_valor.value,
               FrmVendas.vend_livro.value);
         venda.alterar();
      }
      cancelaUpdateVenda();
   }
}

function limparCamposVenda(){
   FrmVendas.vend_comprador.value = '';
   FrmVendas.vend_valor.value = '';
   FrmVendas.vend_livros = '';
}
   
   //Listagem das pessoas
   function listaVendas() {
      firebase.firestore().collection('VENDAS')
         .orderBy('Comprador').onSnapshot(function (dataSnapshot) {
            geralistaVendas(dataSnapshot)
         })
      filtroVenda.onkeyup = function () {
         if (filtroVenda.value != '') {
            var TextoFiltro = filtroVenda.value.toLowerCase()
            firebase.firestore().collection('VENDAS')
               .orderBy('CompradorMinusculo').startAt(TextoFiltro).endAt(TextoFiltro + '\uf8ff')
               .get().then(function (dataSnapshot) {
                  //console.log(dataSnapshot)
                  geralistaVendas(dataSnapshot)
               })
         } else {
            firebase.firestore().collection('VENDAS')
               .orderBy('Comprador').onSnapshot(function (dataSnapshot) {
                  geralistaVendas(dataSnapshot)
               })
         }
      }
   }
   
   //Monta a exibição da listagem de pessoas
   function geralistaVendas(dataSnapshot) {
   
      ulListaVenda.innerHTML = ''
      var num = dataSnapshot.size
   
      // Exibe o número de pessoas
      ContaVendas.innerHTML = 'Total de registros: ' +  num +  (num > 1 ? ' Vendas' : ' venda') +'.';
      dataSnapshot.forEach(function (item) { // Percorre todos os elementos
         var value = item.data()
   
         var li = document.createElement('li') // Cria um elemento do tipo li
   
         li.id = item.id // Define o id do li como a chave da pessoa
   
         var spanLi = document.createElement('sspan') // Cria um elemento do tipo span
         spanLi.appendChild(document.createTextNode(value.Comprador +' / R$ '+  value.Valor +',00')) // Adiciona o elemento de texto dentro da nossa span
         li.appendChild(spanLi) // Adiciona o span dentro do li
   
         //ADICIONA O BOTÃO PARA ALTERAR
         var liUpdateBtn = document.createElement('button') // Cria um botão para a remoção da tarefa
         liUpdateBtn.appendChild(document.createTextNode('Alterar')) // Define o texto do botão como 'Excluir'
   
         liUpdateBtn.setAttribute('onclick', 'alteraVendas(\"'+ item.id +'\")')
         // Configura o onclick do botão de atualização
   
         liUpdateBtn.setAttribute('class', 'CorBotaoDeletarAlterar') // Define classes de estilização para o nosso botão de remoção
         li.appendChild(liUpdateBtn) // Adiciona o botão de remoção no li
   
         //ADICIONA O BOTÃO PARA EXCLUIR
         var liRemoveBtn = document.createElement('button') // Cria um botão para a remoção da tarefa
         liRemoveBtn.appendChild(document.createTextNode('Excluir')) // Define o texto do botão como 'Excluir'
   
         liRemoveBtn.setAttribute('class', 'CorBotaoDeletarExcluir') // Define classes de estilização para o nosso botão de remoção
   
         liRemoveBtn.setAttribute('type', 'button')
   
         liRemoveBtn.setAttribute('onclick', 'excluiVendas(\"'+ item.id +'\")') // Configura o onclick do botão de remoção de tarefas
   
         li.appendChild(liRemoveBtn) // Adiciona o botão de remoção no li
   
   
         ulListaVenda.appendChild(li) // Adiciona o li dentro da lista de tarefas
      })
   }
   
   //FUNÇÃO PARA EXCLUIR UMA PESSOA
   
   function excluiVendas(key) {
      var CompradorVenda = null
      firebase.firestore().collection('VENDAS').doc(key).get().then(function (dados) {
         if (dados.exists) {
            var vend = dados.data()
            var venda = new Venda(key, vend.Comprador, vend.CompradorMinusculo, vend.Valor, vend.Livro);
            console.log(venda.id);
            CompradorVenda = vend.Comprador
             var confimation = confirm('Realmente deseja remover a venda do comprador \"'+ CompradorVenda +'\"?')
             if (confimation) {
              venda.excluir();
            }
         }
      })
   }
   
   
   //FUNÇÃO QUE BUSCA OS DADOS QUE SERÃO ALTERADOS E PREPARA O FORMULÁRIO.
   var updateKeyVenda = null //cria uma variável global e inicializa com null
   function alteraVendas(key) {
      console.log("Chegou no alterar vendas");
      updateKeyVenda = key // Atribui o conteúdo de key dentro de uma variável global
      firebase.firestore().collection('VENDAS').doc(key).get().then(function (dados) {
         if (dados.exists) {
            //Preenche o formulário com os dados da cidade selecionada
            var vend = dados.data()
            FrmVendas.vend_comprador.value = vend.Comprador
            FrmVendas.vend_valor.value = vend.Valor
            FrmVendas.vend_livro.value = vend.Livros
   
            // Altera o título do formulário
            TituloFormVendas.innerHTML = 'Editar vendas do comprador: ' + vend.Comprador;
            OcultaItem(FrmVendaBtnGravar)
            MostraItem(FrmVendaBtnAlterar)
            MenuLivros(vend.Livros);
         }
      })
   }
   
   
   //FUNÇÃO PARA RESTAURAR O FORMULÁRIO DE PESSOA QUANDO O USUÁRIO 
   //CANCELA UMA ALTERAÇÃO
   function cancelaUpdateVenda() {
      console.log("aqui");
      TituloFormVendas.innerHTML = 'Cadastrar uma nova venda'
      OcultaItem(FrmVendaBtnAlterar)
      MostraItem(FrmVendaBtnGravar)
      FrmVendaBtnGravar.style.display = 'initial'
      limparCamposVenda();
}

// funçao para carregar dados no select de cidade 
function MenuLivros(chave){
   console.log('chegou no menu liv');
   firebase.firestore().collection('LIVROS').orderBy('Titulo').onSnapshot(function(dataSnapshot){
      geraMenuLivros(dataSnapshot, chave)
   })
}

function geraMenuLivros(dataSnapshot, chave){
   vend_livro.innerHTML = "";
   dataSnapshot.forEach(function(item){
      var liv = item.data();
      var op = document.createElement('option');
      op.value = item.id;
      op.text = liv.Titulo;
      if(chave == item.id){
         op.selected = true;
         
      }
      vend_livro.appendChild(op)
   })
}